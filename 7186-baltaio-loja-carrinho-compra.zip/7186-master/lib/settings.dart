import 'models/user.model.dart';

class Settings {
  static String apiUrl = "https://balta-eshop.azurewebsites.net/";
  static String theme = "light";
  static UserModel user;
}
