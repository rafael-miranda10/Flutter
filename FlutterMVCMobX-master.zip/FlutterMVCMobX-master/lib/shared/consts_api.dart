class ConstsApi {
  static const POST_URL = 'https://jsonplaceholder.typicode.com/posts';
  static const COMMENT_URL = 'https://jsonplaceholder.typicode.com/comments?postId=';
}