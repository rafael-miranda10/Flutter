## Projeto voltado para demonstrar o uso do Padrão MVC com MobX

### Features
 -  Uso de MobX
 -  Consumo de Api com http
 -  Estruturação de pastas 
 -  Utilização de Repositórios e Interfaces (Contratos)
 -  Utilização de Rotas nomeadas

#### Linkedin: https://www.linkedin.com/in/renatomotadeveloper/
#### Youtube: https://www.youtube.com/channel/UCd-vLa_qcKve3CsDFlYiygA

